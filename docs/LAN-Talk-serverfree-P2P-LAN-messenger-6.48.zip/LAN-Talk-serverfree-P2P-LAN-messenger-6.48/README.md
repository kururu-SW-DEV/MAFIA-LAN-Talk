# LAN Talk(랜톡)

서버 없이 동작하는 **P2P LAN 메신저**입니다. 같은 네트워크(사내망, 집, 학교 등)에 있는 사람들끼리 별도 서버·계정·인터넷 연결 없이 1:1 및 그룹 채팅을 할 수 있습니다. Python 표준 라이브러리만으로 동작하며, Windows용 데스크톱 앱(Tkinter GUI)입니다.

---

## 주요 기능

- **서버 없는 P2P 통신**: UDP 브로드캐스트(기본 포트 `50707`, 3초 간격)로 같은 서브넷의 상대를 자동 발견하고, 다른 네트워크 대역의 상대는 IP를 직접 등록해 연결합니다. 포트는 앱 안 `[＋] → 포트 번호 변경`에서 직접 바꿀 수 있습니다(재시작 후 적용).
- **암호화**: 패킷은 HMAC 인증을 거쳐 암호화 전송되며, 로컬에 저장되는 대화 로그도 암호화됩니다.
- **신뢰성 있는 전송**: 수신 확인(ACK) + 유실 시 최대 3회 자동 재전송.
- **1:1 · 그룹 채팅**: 그룹은 별도 서버 없이 각 멤버에게 개별 유니캐스트로 전파(gossip fan-out)하는 방식으로 동작합니다.
- **자동 폭파 메시지**: 1:1·그룹 모두 타이머를 설정해 일정 시간 후 메시지가 자동으로 사라지게 할 수 있습니다.
- **파일 전송**: 드래그 앤 드롭으로 전송, 이어받기(재개) 지원. 최대 크기는 기본 1024MB(1GB)이며 설정에서 1MB~1GB까지 조절 가능합니다(단, 받는 쪽 설정도 그 크기 이상이어야 전달됩니다). 실행 파일(`.exe`, `.bat`, `.ps1` 등)을 받으면 실행 전 경고를 거칩니다.
- **스티커 · 이모지**: 코드로 직접 그린 오리지널 스티커와 표준 유니코드 이모지 패널을 채팅창에 내장.
- **답장 · 공지사항 고정 · 대화 내 검색**(Ctrl+F).
- **프로필 아바타**: 사진을 등록하면 원형으로 자동 크롭.
- **읽지 않은 메시지 배지, 트레이 알림 및 깜빡임, 다크 타이틀바**(Windows DWM) 등 데스크톱 메신저에 맞는 UI.
- **여러 명에게 한 번에 보내기(브로드캐스트)** 기능.

---

## 요구 사항

- Windows 10/11
- Python 3.10 이상 (표준 라이브러리만으로 동작 — 별도 패키지 설치 없이 바로 실행 가능)
- (선택) [Pillow](https://python-pillow.org/): `.jpg`/`.jpeg` 이미지 미리보기와 프로필 사진 크롭에 사용됩니다. 설치돼 있지 않아도 앱은 정상 동작하며, 이 경우 jpg는 파일 카드로 표시됩니다.
  ```bash
  pip install Pillow
  ```

---

## 실행 방법

### Windows에서 바로 실행
`START_LAN Talk.bat`을 더블클릭하면 `pythonw`(콘솔 창 없이) 또는 `python`으로 자동 실행됩니다.

### 커맨드라인에서 실행
```bash
python lan_messenger.py
```

지원하는 옵션:
```bash
python lan_messenger.py --name "표시이름" --port 50707 --datadir "저장폴더경로" --peers 192.168.0.10:50707,192.168.0.11:50707
```
- `--name`: 표시 이름 (기본값: Windows 로그인 계정명)
- `--port`: 사용 포트 (기본: 앱의 `[＋] → 포트 번호 변경`으로 저장해둔 값, 없으면 `50707`. 이 옵션을 주면 저장된 값보다 우선함)
- `--datadir`: 설정/대화 기록 저장 폴더 (기본값은 실행 위치 기준 자동 결정)
- `--peers`: 같은 서브넷이 아니어서 자동 발견이 안 되는 상대를 `ip:port` 형식으로 콤마 구분해 미리 등록

### 독립 실행파일(exe)로 빌드

Python이 설치되지 않은 PC에도 배포하려면 [PyInstaller](https://pyinstaller.org/)로
단일 exe 파일을 만들 수 있습니다.

```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name "LAN Talk" --icon=app.ico \
  --add-data "app.ico;." --collect-all PIL --exclude-module numpy \
  --version-file=version_info.txt lan_messenger.py
```

빌드된 `dist/LAN Talk.exe`는 그 자체로 포터블입니다 — 처음 실행하는 폴더에
`secret.key`와 `data/`를 자동으로 만들고, 이후 실행마다 그 자리를 그대로
씁니다.

---

## 구조

`lan_messenger.py`가 실행 진입점이며, 실제 구현은 유지보수를 위해 여러 파일로 분리되어 있습니다.

| 파일 | 역할 |
|---|---|
| `constants.py` | 포트·타이밍·색상·폰트·레이아웃·아이콘 등 전역 상수 |
| `netutils.py` | 시간 포맷, 로컬 IP 캐시, 아바타 이미지 처리 등 순수 헬퍼 |
| `canvas_utils.py` | 둥근 모서리 캔버스 그리기 헬퍼 |
| `crypto_layer.py` | 패킷 암호화·인증(HMAC) 계층 + 로그 파일 암호화 |
| `applog.py` | 예외를 파일로 남기는 디버그 로그 |
| `winapi.py` | Windows 트레이 알림·다크 타이틀바 (ctypes 기반) |
| `engine.py` | 네트워크 계층 (`Engine` 클래스) |
| `widgets.py` | 재사용 커스텀 위젯 (스플리터, 스크롤 버튼, 이모지 피커 등) |
| `dnd_handler.py` | 드래그앤드롭·트레이 알림 클릭 처리 믹스인 |
| `chat_search.py` | 대화방 내 검색(Ctrl+F) 믹스인 |
| `chat_renderer.py` | 채팅 캔버스 렌더링(말풍선·자동 폭파 배지 등) 믹스인 |
| `dialogs.py` | 그룹 관리·설정 등 각종 다이얼로그 믹스인 |
| `toast_popup.py` | 인앱 알림 토스트 팝업(슬라이드 애니메이션) |
| `app.py` | 위 믹스인들을 합친 최종 GUI 클래스(`App`) |

---

## 참고

- 같은 로컬 네트워크(LAN) 안에서 사용하도록 설계되었습니다. 인터넷을 통한 원격 연결은 지원하지 않습니다.
- 현재 Windows 전용입니다(트레이 알림·다크 타이틀바 등이 `ctypes`로 Win32 API를 직접 호출).
- `LAN Talk.exe`에는 [Pillow](https://python-pillow.org/)가 번들되어 있습니다. 라이선스 전문은 [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md) 참고.

---

## 변경 이력

간단한 버전별 변경 이력은 [CHANGELOG.md](CHANGELOG.md) 참고.
